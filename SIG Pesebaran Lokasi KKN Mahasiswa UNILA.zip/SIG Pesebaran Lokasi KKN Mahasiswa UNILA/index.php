<?php
    error_reporting(0) ; 
include 'koneksi.php'
?>


<html lang="en"> 
   <head>
  
	<link rel="stylesheet" type="text/css" href="style.css">
      <meta charset="utf-8">
      <title>Judul Halaman Saya</title>
	  <style type="text/css">
		form {
			width:250px;
			margin:50px auto;
		}
		.search {
			padding:8px 15px;
			background:rgba(50, 50, 50, 0.2);
			border:0px solid #dbdbdb;
		}
		.button {
			position:relative;
			padding:6px 15px;
			left:-8px;
			border:2px solid #53bd84;
			background-color:#53bd84;
			color:#fafafa;
		}
		.button:hover  {
			background-color:#fafafa;
			color:#207cca;
		}
				  
		::-webkit-input-placeholder { /* For WebKit browsers */
			color:    #dd3333;
						font-family:Helvetica Neue;
						font-weight:bold;
		}
		:-moz-placeholder { /* For Mozilla Firefox 4 to 18 */
			color:    #dd3333;
						font-family:Helvetica Neue;
						font-weight:bold;
		}
		::-moz-placeholder { /* For Mozilla Firefox 19+ */
			color:    #dd3333;
						font-family:Helvetica Neue;
						font-weight:bold;
		}
		:-ms-input-placeholder { /* For Internet Explorer 10+ */
			color:    #dd3333;
						font-family:Helvetica Neue;
						font-weight:bold;
		}	  
	</style>
   </head>
<body>
	
<form action = "" method = "POST" >
    <input class="search" name = "query" type="text" placeholder="Cari..." required>
    <input class="button" type="button" value="Cari">		
</form> 

<div class="container">
	<h1>Daftar Dosen</h1>
	<table class="highlighted-column">
		<thead>
			<tr>
				<th>No</th>
				<th>Nama Dosen</th>
				<th>Alamat</th>
				<th>Jumlah Mahasiwa</th>
				<th>ID</th>
			</tr>
		</thead>

    <?php
    $no = 1 ; 
    $query = $_POST ['query']; 
    if ($query != '') {
        $select = mysqli_query ($conn, "SELECT * FROM tb_kkn WHERE Nama_Dosen LIKE '".$query."' "); 
    }

    else {
        $select = mysqli_query ($conn, "SELECT * FROM tb_kkn");    
    }
        if (mysqli_num_rows($select)) {
        while ($baris = mysqli_fetch_array($select)) {
?>


<tr>
<td> <?php echo $no++ ?> </td>
<td> <?php echo $baris['Nama_Dosen'] ?> </td>
<td> <?php echo $baris['Alamat'] ?> </td>
<td> <?php echo $baris['Jumlah Mahasiswa'] ?> </td>
<td> <?php echo $baris['ID'] ?> </td>
</tr>
     <?php }} else{
        echo '<tr> <td colspan = "5"> tidak ada data </td></tr>' ; 
     } ?>


    


    </table>

</body>
</html> 