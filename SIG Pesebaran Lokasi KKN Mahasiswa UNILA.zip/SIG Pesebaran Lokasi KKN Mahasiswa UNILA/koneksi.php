<?php
    $conn = mysqli_connect ('localhost', 'id5141252_kkn','12345', 'id5141252_kkn') ; 
    ?>